# WhatsApp-Chat-Analyser
Short Description: Create word clouds and identify sentiments from the WhatsApp chats

Broadly this pacakge will perform data clearning, text preprocessing, and data visualisation over the WhatsApp conversation that you submit. 
Accepted file format includes chats exported as csv files.
